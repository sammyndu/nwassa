﻿
namespace Nwassa.Core.Helpers
{
    public enum CasingType
    {
        None = 0,
        Pascal = 1,
        Camel = 2,
        Snake = 3
    }
}
